import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author BFryc
 * @version 1.0
 */
public class GUI {
    private JPanel mainPane;
    private JTabbedPane tp;
    private JPanel tp1;
    private JPanel tp2;
    private JList tp1JList;
    private JScrollPane tp1ScrollPanel;
    private JPanel tp1Panel2;
    private JTextField tp1TFProductName;
    private JTextField tp1TFProductNumber;
    private JButton tp1dodajProduktButton;
    private JLabel tp1LabelProductName;
    private JLabel tp1LabelProductNumber;
    private JComboBox tp2comboBox;
    private JButton tp2ButtonDodaj;
    private JTextField tp2TFNumber;
    private JLabel tp2LabelNumber;
    private JList tp2OrderList;
    private JButton tp2Save;
    private JScrollPane tp2ScrolPane;
    private JCheckBox tp2checkBox;
    private DefaultListModel listModel;

    List<Produkt> produkty;
    List<Produkt> zamowienia;

    /**
     * Konstruktor bezparametrowy klasy GUI
     */
    public GUI() {
        listModel = new DefaultListModel();
        tp1JList.setModel(listModel);
        produkty = new ArrayList<>();
        zamowienia = new ArrayList<>();
        produkty.add(new Produkt("Mleko", 50));
        produkty.add(new Produkt("Masło", 43));
        produkty.add(new Produkt("Pomidory", 38));
        renderProductList();
        tp1dodajProduktButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(tp1TFProductNumber.getText());
                } catch (NumberFormatException a) {
                    JOptionPane.showMessageDialog(null, "Zła wartość w polu ilośc!");
                }
                if (tp1TFProductName.getText().equals(" ") || tp1TFProductName.getText().equals("") ) {
                    JOptionPane.showMessageDialog(null, "Nie podano nazwy produktu!");
                } else {
                    produkty.add(new Produkt(tp1TFProductName.getText(), Integer.parseInt(tp1TFProductNumber.getText())));
                    renderProductList();
                    tp1TFProductName.setText("");
                    tp1TFProductNumber.setText("");
                }
                // listModel.addElement(tp1TFProductName.getText()+" "+tp1TFProductNumber.getText());
            }
        });

        tp.addChangeListener(new ChangeListener() {
            /**
             * Invoked when the target of the listener has changed its state.
             *
             * @param e a ChangeEvent object
             */
            @Override
            public void stateChanged(ChangeEvent e) {
                if(tp.getSelectedIndex()==0)
                {
                    renderProductList();
                }
                else {
                    renderProductListComboBox();
                }
            }
        });
        tp2ButtonDodaj.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
               String nazwa= tp2comboBox.getSelectedItem().toString();
                zamowienia.add(new Produkt(nazwa, Integer.parseInt(tp2TFNumber.getText())));
                renderZamowienieList();
            }
        });
        tp2Save.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PrintWriter out = new PrintWriter("Zamowienia.txt");
                    out.println("Zamawione produkty: ");
                    for (Produkt p : zamowienia)
                    {
                        out.println(" - "+p.toString());
                    }
                    if(tp2checkBox.isSelected()==true) {

                        out.println("\n\n Zapakować wszystko!");
                    }
                    out.close();
                    JOptionPane.showMessageDialog(null, "Dane zapisano w pliku Zamówienia.txt");

                }
                catch(IOException a)
                {
                    JOptionPane.showMessageDialog(null, "Błąd zapisu do pliku");
                }
            }
        });
    }
   public void renderProductList()
    {
        DefaultListModel <String> listModel= new DefaultListModel<>();
        for(Produkt p: produkty)
        {
            listModel.addElement(p.toString());
        }
        tp1JList.setModel(listModel);
    }
    public void renderZamowienieList()
    {
        DefaultListModel <String> listModel= new DefaultListModel<>();
        for(Produkt p: zamowienia)
        {
            listModel.addElement(p.toString());
        }
        tp2OrderList.setModel(listModel);
    }
 public void renderProductListComboBox()
 {
     tp2comboBox.removeAllItems();
     for(Produkt p: produkty) {
         tp2comboBox.addItem(p.getNazwa());
     }
 }



    /**
     * Funkcja główna klasy GUI
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("GUI");
        frame.setContentPane(new GUI().mainPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(400, 400);
    }
}
