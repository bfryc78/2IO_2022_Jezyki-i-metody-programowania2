/**
 * Klasa Produkt
 */
public class Produkt {
    private String nazwa;
    private int ilosc;

    public Produkt(String nazwa, int ilosc) {
        this.nazwa = nazwa;
        this.ilosc = ilosc;
    }

    public String getNazwa() {
        return nazwa;
    }

    /**
     *
     * getter klasy Produkt
     * @param nazwa ustawiamy nową nazwę produktu
     */
    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public int getIlosc() {
        return ilosc;
    }

    public void setIlosc(int ilosc) {
        this.ilosc = ilosc;
    }

    @Override
    public String toString() {
        return nazwa + " " + ilosc;
    }
}
