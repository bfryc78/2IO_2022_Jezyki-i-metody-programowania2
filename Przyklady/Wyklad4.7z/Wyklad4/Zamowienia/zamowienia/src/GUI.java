import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * @author BFryc
 * @version 1.0
 */
public class GUI {
    private JPanel mainPane;
    private JTabbedPane tp;
    private JPanel tp1;
    private JPanel tp2;
    private JList tp1JList;
    private JScrollPane tp1ScrollPanel;
    private JPanel tp1Panel2;
    private JTextField tp1TFProductName;
    private JTextField tp1TFProductNumber;
    private JButton tp1dodajProduktButton;
    private JLabel tp1LabelProductName;
    private JLabel tp1LabelProductNumber;
    private JComboBox tp2comboBox;
    private JButton tp2ButtonDodaj;
    private JTextField tp2TFNumber;
    private JLabel tp2LabelNumber;
    private JList tp2OrderList;
    private JButton tp2Save;
    private JScrollPane tp2ScrolPane;
    private JCheckBox tp2checkBox;
    private JRadioButton tp1rbSortbyName;
    private JRadioButton tp1rbSortbyNumber;
    private JButton tp1LoadData;
    private ButtonGroup sortowanieGrupa;
    private DefaultListModel listModel;

    List<Produkt> produkty;
    List<Produkt> zamowienia;

    /**
     * Konstruktor bezparametrowy klasy GUI
     */
    public GUI() {
        sortowanieGrupa = new ButtonGroup();
        sortowanieGrupa.add(tp1rbSortbyName);
        sortowanieGrupa.add(tp1rbSortbyNumber);
       // tp1rbSortbyName.setSelected(true);


        listModel = new DefaultListModel();
        tp1JList.setModel(listModel);
        produkty = new ArrayList<>();
        zamowienia = new ArrayList<>();
        produkty.add(new Produkt("Mleko", 50));
        produkty.add(new Produkt("Masło", 43));
        produkty.add(new Produkt("Pomidory", 38));
        renderProductList();
        tp1dodajProduktButton.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int n = Integer.parseInt(tp1TFProductNumber.getText());
                } catch (NumberFormatException a) {
                    JOptionPane.showMessageDialog(null, "Zła wartość w polu ilośc!");
                }
                if (tp1TFProductName.getText().equals(" ") || tp1TFProductName.getText().equals("") ) {
                    JOptionPane.showMessageDialog(null, "Nie podano nazwy produktu!");
                } else {
                    produkty.add(new Produkt(tp1TFProductName.getText(), Integer.parseInt(tp1TFProductNumber.getText())));
                    renderProductList();
                    tp1TFProductName.setText("");
                    tp1TFProductNumber.setText("");
                }
                // listModel.addElement(tp1TFProductName.getText()+" "+tp1TFProductNumber.getText());
            }
        });

        tp.addChangeListener(new ChangeListener() {
            /**
             * Invoked when the target of the listener has changed its state.
             *
             * @param e a ChangeEvent object
             */
            @Override
            public void stateChanged(ChangeEvent e) {
                if(tp.getSelectedIndex()==0)
                {
                    renderProductList();
                }
                else {
                    renderProductListComboBox();
                }
            }
        });
        tp2ButtonDodaj.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {

               String nazwa= tp2comboBox.getSelectedItem().toString();
               int ilosc= Integer.parseInt(tp2TFNumber.getText());
               int i=0;
               for (Produkt p : produkty){
                   if(p.getNazwa().equals(nazwa))
                   {
                       if(p.getIlosc()>=ilosc)
                       {
                           p.setIlosc(p.getIlosc()-ilosc);
                           zamowienia.add(new Produkt(nazwa, Integer.parseInt(tp2TFNumber.getText())));
                       }
                       else if(p.getIlosc()<ilosc)
                       {
                           ilosc=p.getIlosc();
                           p.setIlosc(0);
                           zamowienia.add(new Produkt(nazwa, ilosc));
                       }

                       if(p.getIlosc()==0)
                       {
                           produkty.remove(i);
                           renderProductListComboBox();
                           JOptionPane.showMessageDialog(null, "Brak produktu w magazynie!");
                           break;
                       }
                   }
                   i++;
               }

                renderZamowienieList();
                tp2TFNumber.setText("");
            }
        });
        tp2Save.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    PrintWriter out = new PrintWriter("Zamowienia.txt");
                    out.println("Zamawione produkty: ");
                    for (Produkt p : zamowienia)
                    {
                        out.println(" - "+p.toString());
                    }
                    if(tp2checkBox.isSelected()==true) {

                        out.println("\n\n Zapakować wszystko!");
                    }
                    out.close();
                    JOptionPane.showMessageDialog(null, "Dane zapisano w pliku Zamówienia.txt");

                }
                catch(IOException a)
                {
                    JOptionPane.showMessageDialog(null, "Błąd zapisu do pliku");
                }
            }
        });
        tp1rbSortbyName.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                if(tp1rbSortbyName.isSelected()==true)
                {
                    sortProductList(0);
                    renderProductList();
                }
            }
        });
        tp1rbSortbyNumber.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tp1rbSortbyNumber.isSelected()==true)
                    sortProductList(1);
                    renderProductList();
            }
        });
        tp1LoadData.addActionListener(new ActionListener() {
            /**
             * Invoked when an action occurs.
             *
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                String sciezka="";
                JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
                j.setDialogTitle("Wybierz plik .txt");
                j.setAcceptAllFileFilterUsed(false);
                FileNameExtensionFilter r = new FileNameExtensionFilter("Tylko pliki .txt", "txt");
                j.addChoosableFileFilter(r);

                int o=j.showOpenDialog(null);
                if(o==JFileChooser.APPROVE_OPTION){
                    sciezka=j.getSelectedFile().getAbsolutePath();
                }
                System.out.println(sciezka);
                loadDataFromFile(sciezka);

            }
        });
    }
   public void renderProductList()
    {
        DefaultListModel <String> listModel= new DefaultListModel<>();
        for(Produkt p: produkty)
        {
            listModel.addElement(p.toString());
        }
        tp1JList.setModel(listModel);
    }
    public void renderZamowienieList()
    {
        DefaultListModel <String> listModel= new DefaultListModel<>();
        for(Produkt p: zamowienia)
        {
            listModel.addElement(p.toString());
        }
        tp2OrderList.setModel(listModel);
    }
 public void renderProductListComboBox()
 {
     tp2comboBox.removeAllItems();
     for(Produkt p: produkty) {
         tp2comboBox.addItem(p.getNazwa());
     }
 }

public void sortProductList(int n)   //n=0 sortujemy po nazwie, n=1 -sorujemy po ilosci
{
 if (n==0)
 {
     produkty.sort(new Comparator<Produkt>() {
         @Override
         public int compare(Produkt o1, Produkt o2) {
             return o1.getNazwa().compareTo(o2.getNazwa());
         }
     });
 }
 if(n==1)
 {
     produkty.sort(new Comparator<Produkt>() {
         @Override
         public int compare(Produkt o1, Produkt o2) {
             if(o1.getIlosc()==o2.getIlosc())
                 return 0;
             else if (o1.getIlosc()<o2.getIlosc())
                 return -1;
             else
                 return 1;
         }
     });
 }

}

   public void loadDataFromFile(String s)
    {
        try{

        File f = new File(s);
        BufferedReader br = new BufferedReader(new FileReader(f));

        String st;
        while((st = br.readLine())!=null)
            {
                String [] prod= st.split(" ");
                System.out.println(prod[0]+ " "+prod[1]);
                produkty.add(new Produkt(prod[0], Integer.parseInt(prod[1])));
            }
        renderProductList();

        }catch(IOException e)
        {

        }
    }

    /**
     * Funkcja główna klasy GUI
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("GUI");
        frame.setContentPane(new GUI().mainPane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(400, 400);
    }
}
